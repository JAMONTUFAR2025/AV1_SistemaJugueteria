/**
 * Copyright (C) 2012 tamtam180
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations
 * under the License.
 *
 * @author tamtam180 - kirscheless at gmail.com
 * @see <a href=
 *      "http://google-opensource.blogspot.jp/2011/04/introducing-cityhash.html">http://google-opensource.blogspot.jp/2011/04/introducing-cityhash.html</a>
 * @see <a href="http://code.google.com/p/cityhash/">http://code.google.com/p/cityhash/</a>
 */
package mssql.googlecode.cityhash;
